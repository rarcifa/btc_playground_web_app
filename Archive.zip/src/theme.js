import { createMuiTheme } from "@material-ui/core";

const theme = createMuiTheme({})

export default theme;